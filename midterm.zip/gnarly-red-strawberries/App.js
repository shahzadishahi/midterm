import React, { useState, useEffect } from "react";
import { View, Text, TextInput, Button, FlatList, TouchableOpacity } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import axios from "axios";

const Stack = createStackNavigator();

// Login Screen
const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = () => {
    if (email && password) {
      navigation.replace("JobList");
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: "center", padding: 20 }}>
      <Text style={{ fontSize: 24, textAlign: "center", marginBottom: 20 }}>Login</Text>
      <TextInput
        placeholder="Email"
        value={email}
        onChangeText={setEmail}
        style={{ borderWidth: 1, padding: 10, marginBottom: 10 }}
      />
      <TextInput
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
        style={{ borderWidth: 1, padding: 10, marginBottom: 20 }}
      />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
};

// Job List Screen
const JobListScreen = ({ navigation }) => {
  const [jobs, setJobs] = useState([]);

  useEffect(() => {
    axios
      .get("http://jsonfakery.com/job-past")
      .then((response) => setJobs(response.data))
      .catch((error) => console.error("Error fetching jobs:", error));
  }, []);

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 24, textAlign: "center", marginBottom: 20 }}>Job Listings</Text>
      <FlatList
        data={jobs}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => navigation.navigate("JobDetails", { job: item })}
            style={{
              padding: 15,
              borderBottomWidth: 1,
              backgroundColor: "#f9f9f9",
              marginBottom: 10,
            }}
          >
            <Text style={{ fontSize: 18 }}>{item.title}</Text>
            <Text>{item.company}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

// Job Details Screen
const JobDetailsScreen = ({ route }) => {
  const { job } = route.params;

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text style={{ fontSize: 24, fontWeight: "bold", marginBottom: 10 }}>{job.title}</Text>
      <Text style={{ fontSize: 18, color: "gray" }}>{job.company}</Text>
      <Text style={{ marginVertical: 10 }}>{job.description}</Text>
      <Text style={{ fontWeight: "bold", marginTop: 10 }}>Requirements:</Text>
      <Text>{job.requirements}</Text>
      <TouchableOpacity
        onPress={() => alert("Redirecting to application")}
        style={{
          marginTop: 20,
          backgroundColor: "#007bff",
          padding: 15,
          borderRadius: 5,
        }}
      >
        <Text style={{ color: "white", textAlign: "center" }}>Apply Now</Text>
      </TouchableOpacity>
    </View>
  );
};

// Main App Navigation
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="JobList" component={JobListScreen} />
        <Stack.Screen name="JobDetails" component={JobDetailsScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
